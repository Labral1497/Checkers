﻿using System;

namespace CheckersProject
{
    internal class MessagesForUser
    {

        public static void MsgWelcomeToCheckersGame()
        {
            string msgToUser = string.Format(@"Hi, Welcome To The Checkers Game!
");
            Console.WriteLine(msgToUser);
        }

        public static void MsgAskUserForNameInput()
        {
            string msgToUser = string.Format(@"Please type the player Name: ");
            Console.WriteLine(msgToUser);
        }

        public static void MsgAskUserForBoardSizeInput()
        {
            string msgToUser = string.Format(@"Please enter the desired size of the board you want to play with(6, 8 or 10): ");
            Console.WriteLine(msgToUser);
        }

        public static void AskUserIfHeWantsToKeepPlaying()
        {
            string msgToUser = string.Format(@"Do you want to play another game? (Y/N)");
            Console.WriteLine(msgToUser);
        }

        public static void MsgAskUserForGameModeInput()
        {
            string msgToUser = string.Format("If you want to play against the computer - enter '1', if you wish to play against antoher player - enter '2': ");
            Console.WriteLine(msgToUser);
        }

        public static void MsgAskUserForMoveInput(Player i_PrevPlayer, Player i_CurrPlayer, string i_PreviousMove, int i_FirstTurnFlag)
        {
            string msgToUser = string.Format(@"{0}'s move was ({1}): {2}.
{3}'s turn ({4}), Please enter a move: ", i_PrevPlayer.Name, i_PrevPlayer.Sign, i_PreviousMove, i_CurrPlayer.Name, i_CurrPlayer.Sign);

            if (i_FirstTurnFlag == 0 && !i_PrevPlayer.Equals(i_CurrPlayer))
            {
                msgToUser = string.Format(@"{0}'s turn ({1}), please enter a move: ", i_CurrPlayer.Name, i_CurrPlayer.Sign);
            }

            Console.WriteLine(msgToUser);
        }

        public static void MsgAskUserForAnotherMoveAfterEatInput()
        {
            string msgToUser = string.Format(@"You can still eat, please enter another move: ");
            Console.WriteLine(msgToUser);
        }

        public static void MsgUserWon(string i_PlayerName)
        {
            string msgToUser = string.Format(@"Congratulation {0}, you have won the game!", i_PlayerName);
            Console.WriteLine(msgToUser);
        }

        public static void DisplayPointStatus(Player i_BlackPlayer, Player i_WhitePlayer)
        {
            string msgToUser = string.Format(@"The game status is: 
{0} has {1} points and {2} has {3} points!", i_BlackPlayer.Name, i_BlackPlayer.Score, i_WhitePlayer.Name, i_WhitePlayer.Score);
            Console.WriteLine(msgToUser);
        }

        public static void MsgGameEndedInADraw(string i_BlackPlayerName, string i_WhitePlayerName)
        {
            string msgToUser = string.Format(@"The game between {0} and {1} ended in a draw", i_BlackPlayerName, i_WhitePlayerName);
            Console.WriteLine(msgToUser);
        }

        // ERROR MSGS
        public static void MsgInputPlayerNameIsInvlaid(string i_InputFromUser)
        {
            string msgToUser = string.Format(@"The input '{0}' is not valid, please enter a name containing 10 charcatrs and without spaces.", i_InputFromUser);
            Console.WriteLine(msgToUser);
        }

        public static void MsgInputBoardSizeIsInvlaid()
        {
            string msgToUser = string.Format("Size is invalid, please choose 6, 8 or 10 as size:");
            Console.WriteLine(msgToUser);
        }

        public static void MsgInputGameModeIsInvlaid()
        {
            string msgToUser = string.Format(@"Not a valid option, Please try again:");
            Console.WriteLine(msgToUser);
        }

        public static void MsgInputMoveIsInvlaid(string i_CurrentMove, MistakeIndicator i_MistakeTypeIndicator, Solider i_SnoozeYouLoseSolider)
        {
            string msgToUser = string.Empty;

            if (i_MistakeTypeIndicator == MistakeIndicator.WrongFormat)
            {
                msgToUser = string.Format(@"The move {0} you have typed is in the wrong format. Please try again. ", i_CurrentMove);
            }
            else if (i_MistakeTypeIndicator == MistakeIndicator.NotAValidIndex)
            {
                msgToUser = string.Format(@"The move {0} you have typed is not a valid index on the game board. Please try again. ", i_CurrentMove);
            }
            else if (i_MistakeTypeIndicator == MistakeIndicator.IlegalMove)
            {
                msgToUser = string.Format(@"The move {0} you have typed is ilegal. Please try again. ", i_CurrentMove);
            }
            else if (i_MistakeTypeIndicator == MistakeIndicator.YouSnoozeYouLose)
            {
                msgToUser = string.Format(@"You snooze you lose! 
Now you must move with the solider positioned in: '{0}{1}' on the game board. ", (char)(i_SnoozeYouLoseSolider.Col + 65), (char)(i_SnoozeYouLoseSolider.Row + 97));
            }

            Console.WriteLine(msgToUser);
        }

        public static void MsgInvalidInputOfKeepPlayingFormat()
        {
            string msgToUser = string.Format(@"Please enter a valid optin (Y/N)");
            Console.WriteLine(msgToUser);
        }
    }
}
