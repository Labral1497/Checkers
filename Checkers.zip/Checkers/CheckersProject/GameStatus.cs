﻿namespace CheckersProject
{
    internal enum GameStatus { KeepPlaying = 0, BlackPlayerWon = -1, WhitePlayerWon = 2, GameEndedInADraw = 2 }
}
