﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CheckersProject
{
    internal class GameManagment
    {
        //internal enum GameStatus {KeepPlaying = 0, BlackPlayerWon = -1, WhitePlayerWon = 2, GameEndedInADraw =2 }
        // internal enum Colors { Black = -1, White = 1 }
        // internal enum MistakeIndicator { WrongFormat = 0, NotAValidIndex = 1, IlegalMove = 2, YouSnoozeYouLose = 3 }


        internal static void RunGame()
        {
            Player blackPlayer, whitePlayer;
            Board gameBoard;
            bool keepPlaying = true;

            GameSetup(out gameBoard, out blackPlayer, out whitePlayer);
            while (keepPlaying)
            {
                Console.Clear();
                GameGui.PrintBoard(gameBoard);
                startGame(gameBoard, blackPlayer, whitePlayer);
                askUserIfHeWantsToKeepPlaying(out keepPlaying);
                Console.Clear();
                gameBoard = new Board(gameBoard.Size, blackPlayer, whitePlayer);
            }
        }

        internal static void GameSetup(out Board i_PlayingBoard, out Player io_BlackPlayer, out Player io_WhitePlayer)
        {
            string blackPlayerName, whitePlayerName, playingMode = string.Empty;
            int sizeOfBoard;

            MessagesForUser.MsgWelcomeToCheckersGame();
            MessagesForUser.MsgAskUserForNameInput();
            blackPlayerName = Console.ReadLine();
            while (!InputValidation.CheckNameValidation(blackPlayerName))
            {
                MessagesForUser.MsgInputPlayerNameIsInvlaid(blackPlayerName);
                blackPlayerName = Console.ReadLine();
            }

            MessagesForUser.MsgAskUserForBoardSizeInput();
            while (!InputValidation.CheckSizeOfBoard(Console.ReadLine(), out sizeOfBoard))
            {
                MessagesForUser.MsgInputBoardSizeIsInvlaid();
            }

            MessagesForUser.MsgAskUserForGameModeInput();
            while (!InputValidation.CheckValidPlayingMode(Console.ReadLine(), ref playingMode))
            {
                MessagesForUser.MsgInputGameModeIsInvlaid();
            }

            if (playingMode.Equals("2"))
            {
                MessagesForUser.MsgAskUserForNameInput();
                whitePlayerName = Console.ReadLine();
                while (!InputValidation.CheckNameValidation(whitePlayerName))
                {
                    whitePlayerName = Console.ReadLine();
                }
            }
            else
            {
                whitePlayerName = "Computer";
            }

            io_BlackPlayer = new Player(blackPlayerName, sizeOfBoard, Colors.Black);
            io_WhitePlayer = new Player(whitePlayerName, sizeOfBoard, Colors.White);
            i_PlayingBoard = new Board(sizeOfBoard, io_BlackPlayer, io_WhitePlayer);
        }

        private static void askUserIfHeWantsToKeepPlaying(out bool o_KeepPlaying)
        {
            string userInput;

            MessagesForUser.AskUserIfHeWantsToKeepPlaying();
            userInput = Console.ReadLine();
            o_KeepPlaying = InputValidation.CheckKeepPlayingInputValidation(userInput);
        }

        private static void startGame(Board i_GameBoard, Player i_BlackPlayer, Player i_WhitePlayer)
        {
            GameStatus gameCurrentStatus = GameStatus.KeepPlaying;
            int numOfMoves = 0;
            string currentInputMove = null, previousMove = null;
            Player previousPlayingPlayer = null, currPlayingPlayer, winningPlayer = null;
            Solider lastMovingSolider = null;
            bool turnedIntoKing = false, isEatingMove = false, stopTheGame = false, isInWhile = false;

            while (gameCurrentStatus == GameStatus.KeepPlaying && !stopTheGame)
            {
                if (numOfMoves % 2 == 0)
                {
                    previousPlayingPlayer = i_WhitePlayer;
                    currPlayingPlayer = i_BlackPlayer;
                }
                else
                {
                    previousPlayingPlayer = i_BlackPlayer;
                    currPlayingPlayer = i_WhitePlayer;
                }

                getValidMove(previousPlayingPlayer, currPlayingPlayer, i_GameBoard, numOfMoves, ref isEatingMove, lastMovingSolider,
                    ref previousMove, ref currentInputMove, isInWhile);
                if (currentInputMove.Equals("Q"))
                {
                    stopTheGame = true;
                    break;
                }

                i_GameBoard.MoveSoldier(currentInputMove, ref isEatingMove, ref lastMovingSolider, ref turnedIntoKing);
                i_GameBoard.UpdateAllSolidersAvilableMoves();
                Console.Clear();
                GameGui.PrintBoard(i_GameBoard);
                gameCurrentStatus = i_GameBoard.CheckGameStatus();
                if (gameCurrentStatus != 0)
                {
                    break;
                }

                while (!(ReferenceEquals(lastMovingSolider, null)) && isEatingMove && lastMovingSolider.NumOfEatingMoves > 0 && !turnedIntoKing && gameCurrentStatus == 0 &&
                    !stopTheGame)
                {
                    isInWhile = true;
                    getValidMove(previousPlayingPlayer, currPlayingPlayer, i_GameBoard, numOfMoves, ref isEatingMove, lastMovingSolider, ref previousMove,
                        ref currentInputMove, isInWhile);
                    if (currentInputMove.Equals("Q"))
                    {
                        stopTheGame = true;
                        break;
                    }

                    i_GameBoard.MoveSoldier(currentInputMove, ref isEatingMove, ref lastMovingSolider, ref turnedIntoKing);
                    i_GameBoard.UpdateAllSolidersAvilableMoves();
                    Console.Clear();
                    GameGui.PrintBoard(i_GameBoard);
                    gameCurrentStatus = i_GameBoard.CheckGameStatus();
                }

                isInWhile = false;
                gameCurrentStatus = i_GameBoard.CheckGameStatus();
                numOfMoves++;
            }

            if (gameCurrentStatus == GameStatus.GameEndedInADraw)
            {
                MessagesForUser.MsgGameEndedInADraw(i_BlackPlayer.Name, i_WhitePlayer.Name);
            }
            else
            {
                if (stopTheGame)
                {
                    winningPlayer = previousPlayingPlayer;
                }
                else if (gameCurrentStatus == GameStatus.WhitePlayerWon)
                {
                    winningPlayer = i_WhitePlayer;
                }
                else if (gameCurrentStatus == GameStatus.BlackPlayerWon)
                {
                    winningPlayer = i_BlackPlayer;
                }

                updatePoints(i_BlackPlayer, i_WhitePlayer, winningPlayer);
                Console.Clear();
                MessagesForUser.MsgUserWon(winningPlayer.Name);
            }

            MessagesForUser.DisplayPointStatus(i_BlackPlayer, i_WhitePlayer);
        }

        private static void updatePoints(Player i_BlackPlayer, Player i_WhitePlayer, Player i_WinningPlayer)
        {
            int blackPlayerPoints = 0, whitePlayerPoints = 0;

            foreach (Solider aliveSolider in i_BlackPlayer.Soliders)
            {
                if (aliveSolider.isKing)
                {
                    blackPlayerPoints += 4;
                }
                else
                {
                    blackPlayerPoints++;
                }
            }

            foreach (Solider aliveSolider in i_WhitePlayer.Soliders)
            {
                if (aliveSolider.isKing)
                {
                    whitePlayerPoints += 4;
                }
                else
                {
                    whitePlayerPoints++;
                }
            }

            i_WinningPlayer.Score += Math.Abs(blackPlayerPoints - whitePlayerPoints);
        }

        private static void getRandomMoveFromComputer(Player i_CurrPlayingPlayer, ref string o_CurrentInputMove)
        {
            List<Solider> canMoveSoliders = new List<Solider>(10);
            int randomSolider, randomMoveIndex;
            string randomMove;
            StringBuilder CurrSoliderPositionInString = new StringBuilder();
            Random rnd = new Random();

            if (i_CurrPlayingPlayer.NumOfTotalEatingMoves > 0)
            {
                canMoveSoliders = i_CurrPlayingPlayer.WhichSolidersCanEat();
                randomSolider = rnd.Next(canMoveSoliders.Count - 1);
                randomMoveIndex = rnd.Next(canMoveSoliders[randomSolider].EatingMovesList.Count);
                randomMove = canMoveSoliders[randomSolider].EatingMovesList[randomMoveIndex];
            }
            else
            {
                canMoveSoliders = i_CurrPlayingPlayer.WhichSolidersCanMove();
                randomSolider = rnd.Next(canMoveSoliders.Count - 1);
                randomMoveIndex = rnd.Next(canMoveSoliders[randomSolider].RegularMovesList.Count);
                randomMove = canMoveSoliders[randomSolider].RegularMovesList[randomMoveIndex];
            }

            CurrSoliderPositionInString.Append((char)(canMoveSoliders[randomSolider].Col + 65));
            CurrSoliderPositionInString.Append((char)(canMoveSoliders[randomSolider].Row + 97));
            CurrSoliderPositionInString.Append(">");
            CurrSoliderPositionInString.Append(randomMove);
            o_CurrentInputMove = CurrSoliderPositionInString.ToString();
        }

        internal static void ParseInputParamsToInt(string i_CurrentMove, ref int io_CurRow, ref int io_CurCol, ref int io_MoveRow, ref int io_MoveCol)
        {
            io_CurCol = i_CurrentMove[0] - 65;
            io_CurRow = i_CurrentMove[1] - 97;
            io_MoveCol = i_CurrentMove[3] - 65;
            io_MoveRow = i_CurrentMove[4] - 97;
        }

        private static void getValidMove(Player i_PreviousPlayingPlayer, Player i_CurrPlayingPlayer, Board i_GameBoard, int i_NumOfMoves,
            ref bool i_IsEatingMove, Solider i_LastMovingSolider, ref string i_PreviousMove, ref string i_CurrentInputMove, bool i_IsInWhile)
        {
            StringBuilder CurrSoliderPositionInString = new StringBuilder();
            bool youSnoozeULose = false;
            Solider chosenMovingSolider = null;
            MistakeIndicator mistakeTypeIndicator;

            if (i_IsInWhile)
            {
                if (i_LastMovingSolider.NumOfEatingMoves == 1)
                {
                    CurrSoliderPositionInString.Append((char)(i_LastMovingSolider.Col + 65));
                    CurrSoliderPositionInString.Append((char)(i_LastMovingSolider.Row + 97));
                    CurrSoliderPositionInString.Append(">");
                    CurrSoliderPositionInString.Append(i_LastMovingSolider.EatingMovesList[0]);
                    i_CurrentInputMove = CurrSoliderPositionInString.ToString();
                }
                else
                {
                    if (i_CurrPlayingPlayer.Name.Equals("Computer"))
                    {
                        getRandomMoveFromComputer(i_CurrPlayingPlayer, ref i_CurrentInputMove);

                    }
                    else
                    {
                        MessagesForUser.MsgAskUserForAnotherMoveAfterEatInput();
                        i_CurrentInputMove = Console.ReadLine();
                    }
                }

                while (!i_CurrentInputMove.Equals("Q") && !InputValidation.CheckMoveValidation(i_CurrentInputMove, i_GameBoard,
                    i_CurrPlayingPlayer, ref youSnoozeULose, ref chosenMovingSolider, out mistakeTypeIndicator, i_IsEatingMove, i_LastMovingSolider) && !i_CurrPlayingPlayer.Name.Equals("Computer"))
                {
                    MessagesForUser.MsgInputMoveIsInvlaid(i_CurrentInputMove, mistakeTypeIndicator, chosenMovingSolider);
                    i_CurrentInputMove = Console.ReadLine();
                }

                i_PreviousMove = i_CurrentInputMove;
            }
            else
            {
                if (i_CurrPlayingPlayer.Name.Equals("Computer"))
                {
                    getRandomMoveFromComputer(i_CurrPlayingPlayer, ref i_CurrentInputMove);
                }
                else
                {
                    MessagesForUser.MsgAskUserForMoveInput(i_PreviousPlayingPlayer, i_CurrPlayingPlayer, i_PreviousMove, i_NumOfMoves);
                    i_CurrentInputMove = Console.ReadLine();
                }

                while (!i_CurrentInputMove.Equals("Q") && !InputValidation.CheckMoveValidation(i_CurrentInputMove, i_GameBoard, i_CurrPlayingPlayer, ref youSnoozeULose, ref chosenMovingSolider, out mistakeTypeIndicator) && !i_CurrPlayingPlayer.Name.Equals("Computer"))
                {
                    MessagesForUser.MsgInputMoveIsInvlaid(i_CurrentInputMove, mistakeTypeIndicator, chosenMovingSolider);
                    i_CurrentInputMove = Console.ReadLine();
                }

                i_PreviousMove = i_CurrentInputMove;
            }
        }
    }
}
