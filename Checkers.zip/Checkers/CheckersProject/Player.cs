﻿using System.Collections.Generic;

namespace CheckersProject
{
    internal class Player
    {
        private string m_Name;
        public Colors Color { get; }
        private List<Solider> m_Soliders;
        private char m_Sign;
        private int m_NumOfSoldiersLeft;
        private int m_Score;

        /*first player -> color = -1 = black
         *second player -> color = 1 = white 
         */
        internal Player(string i_Name, int i_SizeOfBoard, Colors i_Color)
        {
            m_Name = i_Name;
            m_Soliders = new List<Solider>(10);
            m_NumOfSoldiersLeft = (i_SizeOfBoard / 2) * ((i_SizeOfBoard / 2) - 1);
            Color = i_Color;
            m_Score = 0;

            if (i_Color == Colors.Black)
            {
                m_Sign = 'X';
            }
            else
            {
                m_Sign = 'O';
            }
        }

        internal List<Solider> WhichSolidersCanEat()
        {
            List<Solider> canEatSoliders = new List<Solider>(5);

            foreach (Solider solider in m_Soliders)
            {
                if (solider.EatingMovesList.Count > 0)
                {
                    canEatSoliders.Add(solider);
                }
            }

            return canEatSoliders;
        }

        internal List<Solider> WhichSolidersCanMove()
        {
            List<Solider> canMoveSoliders = new List<Solider>(5);

            foreach (Solider solider in m_Soliders)
            {
                if (solider.RegularMovesList.Count > 0 || solider.EatingMovesList.Count > 0)
                {
                    canMoveSoliders.Add(solider);
                }
            }

            return canMoveSoliders;
        }

        internal int NumOfTotalEatingMoves
        {
            get
            {
                int countNumOfTotalEatingMoves = 0;

                foreach (Solider solider in m_Soliders)
                {
                    countNumOfTotalEatingMoves += solider.NumOfEatingMoves;
                }
                return countNumOfTotalEatingMoves;
            }
        }

        internal string Name
        {
            get { return m_Name; }
        }

        internal char Sign
        {
            get { return m_Sign; }
        }

        internal int NumOfTotalMoves
        {
            get
            {
                int countNumOfTotalMoves = NumOfTotalEatingMoves;

                foreach (Solider solider in m_Soliders)
                {
                    countNumOfTotalMoves += solider.NumOfRegularMoves;
                }

                return countNumOfTotalMoves;
            }
        }

        internal int NumOfSoldiersLeft
        {
            get { return m_NumOfSoldiersLeft; }
            set { m_NumOfSoldiersLeft = value; }
        }

        internal int Score
        {
            get { return m_Score; }
            set { m_Score = value; }
        }

        internal List<Solider> Soliders
        {
            get { return m_Soliders; }
        }
    }
}
