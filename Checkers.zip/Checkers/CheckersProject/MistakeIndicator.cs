﻿namespace CheckersProject
{
    internal enum MistakeIndicator { WrongFormat = 0, NotAValidIndex = 1, IlegalMove = 2, YouSnoozeYouLose = 3 }
}
