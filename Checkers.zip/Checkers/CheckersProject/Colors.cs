﻿namespace CheckersProject
{
    internal enum Colors { Black = -1, White = 1 }
}
