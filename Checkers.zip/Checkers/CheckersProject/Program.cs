﻿namespace CheckersProject
{
    public class Program
    {
        public static void Main()
        {
            GameManagment.RunGame();
        }
    }
}
