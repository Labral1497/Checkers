﻿using System;
using System.Text;

namespace CheckersProject
{
    internal class GameGui
    {
        internal static void PrintBoard(Board i_GameBoard)
        {
            Solider currSolider;
            string lineSperator, curSoldierString;
            int sizeOfBoard = i_GameBoard.Size;
            StringBuilder currentLine = new StringBuilder();

            lineSperator = new string('=', (sizeOfBoard * 4) + 1);
            lineSperator = string.Format(@" {0}
", lineSperator);
            currentLine = currentLine.Append(string.Format(@"   "));
            for (int i = 0; i < sizeOfBoard; i++)
            {
                currentLine.Append(string.Format(@"{0}   ", (char)((int)('A') + i)));
            }

            currentLine.AppendLine();
            Console.Write(currentLine);
            currentLine.Clear();
            Console.Write(lineSperator);
            for (int i = 0; i < sizeOfBoard; i++)
            {
                currentLine.Append((char)((int)('a') + i) + "|");
                for (int j = 0; j < sizeOfBoard; j++)
                {
                    currSolider = i_GameBoard.GameBoard[i, j];
                    if (currSolider != null)
                    {
                        curSoldierString = currSolider.ToString();
                    }
                    else
                    {
                        curSoldierString = " ";
                    }

                    currentLine.Append(string.Format(@" {0} |", curSoldierString));
                }

                currentLine.AppendLine();
                Console.Write(currentLine);
                Console.Write(lineSperator);
                currentLine.Clear();
            }

            Console.WriteLine();
            Console.WriteLine();
        }
    }
}
