﻿using System;

namespace CheckersProject
{
    internal class InputValidation
    {
        internal static bool CheckNameValidation(string i_PlayerOneName)
        {
            bool nameIsValid = true;

            if (i_PlayerOneName.Length > 10 || i_PlayerOneName.Contains(" ") || i_PlayerOneName.Equals("Computer"))
            {
                nameIsValid = false;
            }

            return nameIsValid;
        }

        internal static bool CheckSizeOfBoard(string i_UserSizeInput, out int io_SizeOfBoard)
        {
            bool isSizeValid = false;

            if (int.TryParse(i_UserSizeInput, out io_SizeOfBoard))
            {
                if (io_SizeOfBoard == 6 || io_SizeOfBoard == 8 || io_SizeOfBoard == 10)
                {
                    isSizeValid = true;
                }
            }

            return isSizeValid;
        }

        internal static bool CheckValidPlayingMode(string i_UserPlayingModeInput, ref string o_PlayingMode)
        {
            bool playingModeIsValid = false;

            if (i_UserPlayingModeInput.Equals("1") || i_UserPlayingModeInput.Equals("2"))
            {
                playingModeIsValid = true;
                o_PlayingMode = i_UserPlayingModeInput;
            }

            return playingModeIsValid;
        }

        internal static bool CheckMoveValidation(string i_CurrentMove, Board i_GameBoard, Player i_CurrentPlayer, ref bool io_YouSnoozeULose,
            ref Solider io_ChosenSoliderWhenMoveIsInvalid, out MistakeIndicator o_MistakeTypeIndicator, bool i_PlayingInARow = false,
            Solider i_LastMovingSoldier = null)
        {
            int curRow = -1, curCol = -1, moveRow = -1, moveCol = -1;
            bool inputIsValid = false;
            Solider movingSoldier;
            o_MistakeTypeIndicator = MistakeIndicator.WrongFormat;

            if (checkIfMoveFormatIsValid(i_CurrentMove))
            {
                GameManagment.ParseInputParamsToInt(i_CurrentMove, ref curRow, ref curCol, ref moveRow, ref moveCol);
                if (IsIndexValid(curRow, curCol, i_GameBoard.Size) && (IsIndexValid(moveRow, moveRow, i_GameBoard.Size)))
                {
                    movingSoldier = i_GameBoard.GameBoard[curRow, curCol];
                    if (!io_YouSnoozeULose)
                    {
                        io_ChosenSoliderWhenMoveIsInvalid = movingSoldier;
                    }

                    if (checkIfMoveIsLegal(movingSoldier, i_LastMovingSoldier, i_CurrentMove, i_PlayingInARow, i_CurrentPlayer, ref io_YouSnoozeULose,
                        ref io_ChosenSoliderWhenMoveIsInvalid))
                    {
                        inputIsValid = true;
                    }
                    else
                    {
                        o_MistakeTypeIndicator = MistakeIndicator.IlegalMove;
                        if (io_YouSnoozeULose && !ReferenceEquals(io_ChosenSoliderWhenMoveIsInvalid, movingSoldier))
                        {
                            o_MistakeTypeIndicator = MistakeIndicator.YouSnoozeYouLose;
                        }
                    }
                }
                else
                {
                    o_MistakeTypeIndicator = MistakeIndicator.NotAValidIndex;
                }
            }
            else
            {
                o_MistakeTypeIndicator = MistakeIndicator.WrongFormat;
            }

            return inputIsValid;
        }

        internal static bool CheckKeepPlayingInputValidation(string i_UserInput)
        {
            bool keepPlaying = false;

            while (!i_UserInput.Equals("Y") && !i_UserInput.Equals("N"))
            {
                MessagesForUser.MsgInvalidInputOfKeepPlayingFormat();
                i_UserInput = Console.ReadLine();
            }

            if (i_UserInput.Equals("Y"))
            {
                keepPlaying = true;
            }

            return keepPlaying;
        }

        private static bool checkIfMoveIsLegal(Solider i_MovingSolider, Solider i_LastMovingSoldier, string i_CurrentMove,
            bool i_PlayingInARow, Player i_CurrentPlayer, ref bool i_YouSnoozeULose, ref Solider i_ChosenSoliderWhenMoveIsInvalid)
        {
            string moveDest;
            bool inputIsValid = false;

            if (i_MovingSolider != null && i_MovingSolider.Color == i_CurrentPlayer.Color && ReferenceEquals(i_MovingSolider, i_ChosenSoliderWhenMoveIsInvalid))
            {
                moveDest = i_CurrentMove.Substring(3, 2);
                if (i_PlayingInARow)
                {
                    if (i_LastMovingSoldier.Equals(i_MovingSolider) && i_MovingSolider.EatingMovesList.Contains(moveDest))
                    {
                        inputIsValid = true;
                    }
                }
                else
                {
                    if (i_MovingSolider.RegularMovesList.Contains(moveDest) && i_CurrentPlayer.NumOfTotalEatingMoves == 0)
                    {
                        inputIsValid = true;
                    }
                    else if (i_MovingSolider.EatingMovesList.Contains(moveDest))
                    {
                        inputIsValid = true;
                    }
                }
            }

            if (!ReferenceEquals(i_MovingSolider, null) && !inputIsValid && (i_MovingSolider.RegularMovesList.Count > 0 || i_MovingSolider.EatingMovesList.Count > 0)
                && i_CurrentPlayer.NumOfTotalEatingMoves == 0 && i_CurrentPlayer.Color == i_MovingSolider.Color)
            {
                i_YouSnoozeULose = true;

            }
            else
            {
                i_YouSnoozeULose = false;
            }

            return inputIsValid;
        }

        private static bool checkIfMoveFormatIsValid(string i_CurrentMove)
        {
            bool inputIsValid = false;

            if (i_CurrentMove.Length == 5 && i_CurrentMove[2].Equals('>') && !Char.IsLower(i_CurrentMove[0]) &&
               Char.IsLower(i_CurrentMove[1]) && !Char.IsLower(i_CurrentMove[3]) && Char.IsLower(i_CurrentMove[4]))
            {
                inputIsValid = true;
            }

            return inputIsValid;
        }

        internal static bool IsIndexValid(int i_CurRow, int i_CurCol, int i_SizeOfBoard)
        {
            bool isIndexInBounds = true;

            if (i_CurRow < 0 || i_CurRow >= i_SizeOfBoard || i_CurCol < 0 || i_CurCol >= i_SizeOfBoard)
            {
                isIndexInBounds = false;
            }

            return isIndexInBounds;
        }
    }
}
