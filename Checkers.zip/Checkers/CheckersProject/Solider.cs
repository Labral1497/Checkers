﻿using System.Collections.Generic;
using System.Text;

namespace CheckersProject
{
    internal class Solider
    {
        private enum SoliderSigns { BlackSolider = 'X', WhiteSolider = 'O', BlackKing = 'Z', WhiteKing = 'Q' }

        private int m_Row;
        private int m_Col;
        private Colors m_Color;
        private int m_SizeOfBoard;
        private bool m_KingFlag;
        private List<string> m_RegularMoves;
        private List<string> m_EatingMoves;

        /* Player / Solider color types:
         * 1 -> white
         * -1 -> black
         */
        internal Solider(Colors i_Color, int i_Row, int i_Col, int i_SizeOfBoard)
        {
            m_Col = i_Col;
            m_Row = i_Row;
            m_KingFlag = false;
            m_SizeOfBoard = i_SizeOfBoard;
            m_Color = i_Color;
            m_EatingMoves = new List<string>(2);
            m_RegularMoves = new List<string>(2);
        }

        internal void UpdateAvailableMoves(Solider[,] i_BoardMatrix)
        {
            int posFlagRight, posFlagLeft, posFlagRightKing, posFlagLeftKing, rightSideOfMove = 1, leftSideOfMove = -1;
            bool checkKingMoves = true;

            m_RegularMoves.Clear();
            m_EatingMoves.Clear();
            posFlagLeft = checkMoveType(i_BoardMatrix, m_Row + IntColor, m_Col - 1, leftSideOfMove);
            posFlagRight = checkMoveType(i_BoardMatrix, m_Row + IntColor, m_Col + 1, rightSideOfMove);
            addMoveToAvalibleMovesList(-1, posFlagLeft, !checkKingMoves);
            addMoveToAvalibleMovesList(1, posFlagRight, !checkKingMoves);

            if (m_KingFlag)
            {
                posFlagLeftKing = checkMoveType(i_BoardMatrix, m_Row - IntColor, m_Col - 1, leftSideOfMove);
                posFlagRightKing = checkMoveType(i_BoardMatrix, m_Row - IntColor, m_Col + 1, rightSideOfMove);
                addMoveToAvalibleMovesList(-1, posFlagLeftKing, checkKingMoves);
                addMoveToAvalibleMovesList(1, posFlagRightKing, checkKingMoves);
            }
        }
        /*
         * EatingMove -> 2 else -> 1
         * sideOfMove -> RIGHT 1 , else -> -1
         */
        private void addMoveToAvalibleMovesList(int i_SideOfMove, int i_EatingMove, bool i_CheckingKingMoves)
        {
            StringBuilder moveName = new StringBuilder();

            if (i_CheckingKingMoves)
            {
                moveName.Append((char)(Col + (i_SideOfMove * i_EatingMove) + 65));
                moveName.Append((char)(Row - (i_EatingMove * IntColor) + 97));

                if (i_EatingMove == 1)
                {
                    m_RegularMoves.Add(moveName.ToString());
                }
                else if (i_EatingMove == 2)
                {
                    m_EatingMoves.Add(moveName.ToString());
                }
            }
            else
            {
                moveName.Append((char)(Col + (i_SideOfMove * i_EatingMove) + 65));
                moveName.Append((char)(Row + (i_EatingMove * IntColor) + 97));
                if (i_EatingMove == 1)
                {
                    m_RegularMoves.Add(moveName.ToString());
                }
                else if (i_EatingMove == 2)
                {
                    m_EatingMoves.Add(moveName.ToString());
                }
            }
        }

        /**
         * Return types:
         * -1 -> out of bounds / same color soldier
         * 1 -> can move
         * 2 -> can eat
         * 
         * i_SideOfMove:
         * -1 -> left side
         * 1 -> right side
         */
        private int checkMoveType(Solider[,] i_BoardMatrix, int i_Row, int i_Col, int i_sideOfMove)
        {
            int typeOfMove = -1;

            if (!InputValidation.IsIndexValid(i_Row, i_Col, m_SizeOfBoard))
            {
                typeOfMove = -1;
            }
            else if (i_BoardMatrix[i_Row, i_Col] == null)
            {
                typeOfMove = 1;
            }
            else if (i_BoardMatrix[i_Row, i_Col].Color != Color)
            {
                if (InputValidation.IsIndexValid(i_Row + IntColor, i_Col + i_sideOfMove, m_SizeOfBoard) && i_BoardMatrix[i_Row + IntColor, i_Col + i_sideOfMove] == null)
                {
                    typeOfMove = 2;
                }
            }

            return typeOfMove;
        }

        public override string ToString()
        {
            string resultString;

            if (Color == Colors.White)
            {
                if (m_KingFlag)
                {
                    resultString = char.ToString((char)SoliderSigns.WhiteKing);
                }
                else
                {
                    resultString = char.ToString((char)SoliderSigns.WhiteSolider);
                }
            }
            else
            {
                if (m_KingFlag)
                {
                    resultString = char.ToString((char)SoliderSigns.BlackKing);
                }
                else
                {
                    resultString = char.ToString((char)SoliderSigns.BlackSolider);
                }
            }

            return resultString;
        }

        internal List<string> EatingMovesList
        {
            get { return m_EatingMoves; }
        }

        internal List<string> RegularMovesList
        {
            get { return m_RegularMoves; }
        }

        internal int Row
        {
            get { return m_Row; }
            set { m_Row = value; }
        }

        internal int Col
        {
            get { return m_Col; }
            set { m_Col = value; }
        }

        internal Colors Color
        {
            get { return m_Color; }
            set { m_Color = value; }
        }

        internal int IntColor
        {
            get { return (int)Color; }
        }

        internal int NumOfRegularMoves
        {
            get { return m_RegularMoves.Count; }
        }

        internal int NumOfEatingMoves
        {
            get { return m_EatingMoves.Count; }
        }

        internal bool isKing
        {
            get { return m_KingFlag; }
            set { m_KingFlag = value; }
        }

    }
}
