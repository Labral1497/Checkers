﻿using System;

namespace CheckersProject
{
    internal class Board
    {
        private readonly int m_SizeOfBoard;
        private Solider[,] m_Board;
        private Player m_BlackPlayer;
        private Player m_WhitePlayer;

        internal Board(int i_SizeOfBoard, Player i_Player1, Player i_Player2)
        {
            m_BlackPlayer = i_Player1;
            m_WhitePlayer = i_Player2;
            m_SizeOfBoard = i_SizeOfBoard;
            m_Board = new Solider[i_SizeOfBoard, i_SizeOfBoard];
            Player curPlayer;
            Solider newSoliderOnBoard;
            int rowIndexToUpdateMovesForBlackSoldiers = (i_SizeOfBoard / 2) + 1, rowIndexToUpdateMovesForWhiteSoldiers = (i_SizeOfBoard / 2) - 2;
            Colors playerColor;

            for (int i = 0; i < i_SizeOfBoard; i++)
            {
                for (int j = 0; j < i_SizeOfBoard && i != i_SizeOfBoard / 2 && i != (i_SizeOfBoard / 2) - 1; j++)
                {
                    if (i < (i_SizeOfBoard / 2) - 1)
                    {
                        playerColor = Colors.White;
                        curPlayer = m_WhitePlayer;
                    }
                    else
                    {
                        playerColor = Colors.Black;
                        curPlayer = m_BlackPlayer;
                    }

                    if ((i % 2 == 0 && j % 2 != 0) || (i % 2 == 1 && j % 2 == 0))
                    {
                        newSoliderOnBoard = new Solider(playerColor, i, j, i_SizeOfBoard);
                        if (newSoliderOnBoard.Row == rowIndexToUpdateMovesForWhiteSoldiers || newSoliderOnBoard.Row == rowIndexToUpdateMovesForBlackSoldiers)
                        {
                            newSoliderOnBoard.UpdateAvailableMoves(m_Board);
                        }

                        curPlayer.Soliders.Add(newSoliderOnBoard);
                        m_Board[i, j] = newSoliderOnBoard;
                    }
                }
            }
        }
        /*
        * if i_EatingInARow == true -> must be eating move.
        * else -> can be regular move.
        */
        internal void MoveSoldier(string i_CurrentMove, ref bool io_IsEatMove, ref Solider io_LastMovingSoldier, ref bool io_TurnedIntoKing)
        {
            int curRow = -1, curCol = -1, moveRow = -1, moveCol = -1;
            Solider movingSolider, eatenSolider;

            GameManagment.ParseInputParamsToInt(i_CurrentMove, ref curRow, ref curCol, ref moveRow, ref moveCol);
            movingSolider = m_Board[curRow, curCol];
            movingSolider.Row = moveRow;
            movingSolider.Col = moveCol;
            m_Board[curRow, curCol] = null;
            m_Board[moveRow, moveCol] = movingSolider;
            io_LastMovingSoldier = movingSolider;
            if (Math.Abs(curRow - moveRow) == 2)
            {
                io_IsEatMove = true;
            }
            else
            {
                io_IsEatMove = false;
            }

            if (io_IsEatMove)
            {
                eatenSolider = m_Board[(moveRow + curRow) / 2, (curCol + moveCol) / 2];
                m_Board[(moveRow + curRow) / 2, (curCol + moveCol) / 2] = null;
                if (movingSolider.Color == Colors.Black)
                {
                    m_WhitePlayer.Soliders.Remove(eatenSolider);
                }
                else
                {
                    m_BlackPlayer.Soliders.Remove(eatenSolider);
                }
            }

            if (((movingSolider.Color == Colors.Black && movingSolider.Row == 0) || (movingSolider.Color == Colors.White && movingSolider.Row == m_SizeOfBoard - 1)) && (!movingSolider.isKing))
            {
                movingSolider.isKing = true;
                io_TurnedIntoKing = true;
            }
            else
            {
                io_TurnedIntoKing = false;
            }
        }

        internal void UpdateAllSolidersAvilableMoves()
        {
            foreach (Solider currSolider in m_Board)
            {
                if (currSolider != null)
                {
                    currSolider.UpdateAvailableMoves(m_Board);
                }
            }
        }
        /*  gameStatus parms:
         * 0 -> game is ongoing
         * -1 -> black player (player 1) won
         * 1 -> white player (player 2) won
         * 2 -> game ended in a draw.
         */
        internal GameStatus CheckGameStatus()
        {
            GameStatus gameStatus = GameStatus.KeepPlaying;

            if (m_BlackPlayer.NumOfTotalMoves == 0 && m_WhitePlayer.NumOfTotalMoves == 0)
            {
                gameStatus = GameStatus.GameEndedInADraw;
            }

            if (m_BlackPlayer.NumOfSoldiersLeft == 0 || m_BlackPlayer.NumOfTotalMoves == 0)
            {
                gameStatus = GameStatus.WhitePlayerWon;
            }

            if (m_WhitePlayer.NumOfSoldiersLeft == 0 || m_WhitePlayer.NumOfTotalMoves == 0)
            {
                gameStatus = GameStatus.BlackPlayerWon;
            }

            return gameStatus;
        }

        internal int Size
        {
            get { return m_SizeOfBoard; }
        }

        internal Solider[,] GameBoard
        {
            get { return m_Board; }
        }
    }
}
